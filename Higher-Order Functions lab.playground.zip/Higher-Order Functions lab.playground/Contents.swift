import UIKit

//: [Previous](@previous)

import Foundation

//Exercisw 1
func foo (fName: String, lName: String, closer: (String, String)-> String) -> String{
    let fullName = closer(fName, lName)
    return fullName
}
let  fullName = foo(fName: "Sarraa", lName: "Almudayfir", closer: {$0 + " " + $1})
print(fullName)



//Exercise 2
var arr = [30,3,10,1,20]

func foo2 ( array: [Int], closur: (Int)-> Bool)-> [Int]{
//    let filterArray = closur(array)
    return array.filter{closur ($0)}
}
let arr1 = foo2(array: arr){ $0 < 4}
print(arr1)






