import UIKit
//E.1
var cars= {(car1: String, car2: String) -> String in
  var cars= (car1 +" "+ car2)
    return cars
}
//E.2 --------------------------------------

var numbers: [Int]= [100,200,300,400]
var arguments = numbers.filter {(numbers:Int)-> Bool in
return numbers
}
print([0])

//E.3 --------------------------------------

var num: [Int] = [1,2,3,4]
var num1 = num.map{(number: Int)-> [Int] in
    return num
//E.4 ---------------------------------------
    var num2:[Int]=[1,2,3,4,5]
    var numbers2=num2.forEach((nums:Int)-> [Int] in){
        return num2
    }
//E.5 ----------------------------------------
    var num3:[Int]=[1,2,3,4,5,6,]
    var numbers3=num3.first(where: ((nums:Int)->[Int] in)) {
       return num3
    }
