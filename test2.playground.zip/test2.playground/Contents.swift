import UIKit




// Static method




//
//
//let allBooks = [book1,book2,book3]
//let sortedBooks = allBooks.sorted( )
//{
//    $0.price >= $1.price
//}


// -MARK: EX1
func str(str1: String, str2: String, str3:(String,String) -> String) -> String {
 
    return str3(str1, str2)
}
print(str(str1: "Ahmed ", str2: "Alharbi") { $0 + $1})

// -MARK: EX2

var myArr = [1,2,3,4,5]

func arrNum(arr: [Int], arrClo:(Int) -> Bool) -> [Int] {
    
    return arr.filter { arrClo($0)}
}

print(arrNum(arr: [1,2,3,4,5,6,7,8,9] ){$0.isMultiple(of: 3)})


// -MARK: EX3

var arrTst = [9,8,7,6,5,4,3,2,1]

func myArr2(arr1: [Int], intClo:(Int) -> Int ) ->[Int] {
    return arr1.map{$0}
}
print(myArr2(arr1: [2,3,4,5], intClo: { $0 + 1}))


// -MARK: EX4

func myArr3(arr1: [Int], inClosure: (Int) -> Void) -> [Int] {
    var emp:[Int] = []
    arr1.forEach { number in
        emp.append(number)
    }
    return emp
}

print(myArr3(arr1: [1,2,3,4], inClosure: { $0}))

func myArr4(arr1:[Int], inClo:(Int) -> Bool) -> [Int] {
    var newArr:[Int] = []
    
    arr1.first(where: inClo)
    newArr += arr1
    
    
    return newArr
    }

print(myArr4(arr1: [2,4,5,7], inClo: { $0 > 3
}))
