import UIKit

//var greeting = "Hello, playground"

//--------------------------------------------------------------------------------
//Ex:1

var c = {(firstName:String,lastName:String)->String in

   let result=firstName+" "+lastName
  return result
}
//-------------------------------------------------------------------------------
// Ex :2
//var array :[Int]=[11,12,54,33,40,52,63]
//func arr( array:[Int]){
//
//
////
//}
////var array1 =[11,12,54,33,40,52,63]
////print(arr(array: array1))

var array:[Int]=[11,12,54,33,40,52,63]
var filteredArray=array.filter {(array:Int)-> Bool in
   return true
}
print(array)
//------------------------------------
//Ex:3
var array1:[Int]=[1,3,4,5,3]
var mapaArray=array1.map{(array:Int)-> [Int] in
   
   return array1
}
   //print(array1)
//----------------------------------------------------------
//Ex:4
var array2:[Int]=[1,2,9,3,4,]
var forEachArray=array2.forEach((array:Int)-> [Int] in){
   return array1
}
//----------------------------------------------------------
//Ex:5
var array3:[Int]=[1,2,4,5,9]
var forEachArray=array3.first(where: ((array:Int)-> [Int] in)){
   return array1
}
