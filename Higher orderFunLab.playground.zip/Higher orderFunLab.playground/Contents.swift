func foo(firstName:String, lastName:String , clousure :(String,String)->String)->String  {
    let fullName = clousure(firstName,lastName)
    return fullName
}


var result = foo(firstName: "Nada", lastName: "A" , clousure: {$0 + " " + $1})
print(result)






var arraryOfInt = [Int]()
//
//func arrayAndCl (arr: [int] ,clousure:(int)->Bool){
//
//}
