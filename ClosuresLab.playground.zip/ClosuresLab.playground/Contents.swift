import SwiftUI

// MARK: - Excercise 1

func concat(str1: String, str2: String, myClosure: (String, String) -> String) -> String {
    return myClosure(str1, str2)
}

print(concat(str1: "A", str2: "B") { $0 + $1 })

// MARK: - Excercise 2

let arr1 = [1,2,30,4,55,6]
func filteredArray(_ arr:[Int], myClosure: (Int) -> Bool) -> [Int] {
    return arr.filter(myClosure)
}
print(filteredArray(arr1) { $0 < 10 })

// MARK: - Excercise 3

let arr2 = [3,4,80,12,24]
func mappedArray( _ arr: [Int], myClosure: (Int) -> Int) -> [Int] {
    return arr.map(myClosure)
}
print(mappedArray(arr2, myClosure: { $0 + 100 }))

// MARK: - Excercise 4

let arr3 = [10, 20 , 30, 40]
func iteration(_ arr: [Int], myClosure: (Int) -> ()) {
    arr.forEach { num in
        myClosure(num)
    }
}

// MARK: - Excercise 5

let arr4 = [5,7,8,2,1]
func firstWhere(_ arr: [Int], myClosure: (Int) -> Bool) -> Int {
    // return -1 in case of empty array
    return arr.first(where: myClosure) ?? -1
}
print(firstWhere(arr4, myClosure: { $0 < 3 }))

/*  Summarize what you learned */
print("""
    \n
    SUMMARIZE WHAT YOU LEARNED

    - How to create a closure
    - How to pass a closure into another function
    - Passing a closure into a function gives possiblities for multiple use cases
    - Differnt ways of writing a closure
    - A better understanding of the Built-in Swift closures
""")

/* Using one HO_Function function over the other */
print("""
    \n
    USING 1 HIGH-ORDER FUNCTION OVER THE OTHER

    * Depends on the use case
     - Do I need to create a function, or does it exist already?
     - Does my code require String manupulation?
     - Does my code require Array manupulation?
     - What return type do I need from the function?
""")
